# WebProjects
 Web sites projects.

## Desafios
 Desafios propostos por Bedimcode e desenvolvidos por mim (in english).

## Links

* Button Loading - https://maxsuel-santos.github.io/WebProjects/button-loading-animation-main

* Portfolio Responsive - https://maxsuel-santos.github.io/WebProjects/portfolio-responsive-complete-master

* Responsive Clock - https://maxsuel-santos.github.io/WebProjects/responsive-clock-ui-main

* Responsive Mini Portfolio - https://maxsuel-santos.github.io/WebProjects/responsive-mini-portfolio-main

* Responsive Navbar - https://maxsuel-santos.github.io/WebProjects/responsive-navbar-main

* Responsive Plants Website - https://maxsuel-santos.github.io/WebProjects/responsive-plants-website-main

* Responsive Travel Website - https://maxsuel-santos.github.io/WebProjects/responsive-travel-website-main

* Responsive Restaurant Website - https://maxsuel-santos.github.io/WebProjects/responsive-website-restaurant-main

* Skeuomorphism Toggle Switch - https://maxsuel-santos.github.io/WebProjects/skeuomorphism-toggle-switch-main

## Linguagens e Ferramentas Utilizadas
![icon](https://github.com/Maxsuel-Santos/Maxsuel-Santos/raw/main/_GitHub/img/html-icon.svg)
![icon](https://github.com/Maxsuel-Santos/Maxsuel-Santos/raw/main/_GitHub/img/css-icon.svg)
![icon](https://github.com/Maxsuel-Santos/Maxsuel-Santos/raw/main/_GitHub/img/sass-icon.svg)
![icon](https://github.com/Maxsuel-Santos/Maxsuel-Santos/raw/main/_GitHub/img/javascript-icon.svg)
